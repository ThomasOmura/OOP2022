# File name: 9Q.py
# Author: Thomás Rizzi Omura
# Description: function that returns a random number between 1-6.

import random

#random integer from 0 to 6
num1 = random.randint(0,6)
print(num1)
