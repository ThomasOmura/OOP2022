# File name: 3Q.py
# Author: Thomás Rizzi Omura
# Description: Arranges numbers in the list from smallest to largest and strings

scores = [96, 42, 72, 9, 1, 45, 39, 20, 18]
scores.sort()

print(scores)