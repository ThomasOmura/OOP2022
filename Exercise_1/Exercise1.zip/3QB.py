from mimetypes import guess_type


# File name: 3QB.py
# Author: Thomás Rizzi Omura
# Description: Arranges the names in the list in alphabetical order

guests = ["Roberto","Thomás","Julio","Luan","Angelo","Gustavo"]

guests.sort()

print(guests)