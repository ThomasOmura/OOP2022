# File name: 1Q.py
# Author: Thomás Rizzi Omura
# Description: A code that prints out Hello World.

print("Hello World")
